//
//  CarthageKit.h
//  CarthageKit
//
//  Created by Justin Spahr-Summers on 2014-10-10.
//  Copyright (c) 2014 Carthage. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CarthageKit.
FOUNDATION_EXPORT double CarthageKitVersionNumber;

//! Project version string for CarthageKit.
FOUNDATION_EXPORT const unsigned char CarthageKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CarthageKit/PublicHeader.h>


